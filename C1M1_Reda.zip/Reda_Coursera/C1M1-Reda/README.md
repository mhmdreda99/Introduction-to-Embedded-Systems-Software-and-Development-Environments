# Author: Mohamed Reda
# Assignment (1)
## description
   ### The folder contains:   

The stats.c and stats.h files  have some premade function comment format for you to enter data into. You will need to include your name as the author, the date, and a small description of the file at the top. If you open stats.c  you will see you have been given part of a main() function. Main has defined an array of 40 characters for testing.



i wrote eight functions in the stats.c implementation file:

main() - The main entry point for your program
print_statistics() - A function that prints the statistics of an array including minimum, maximum, mean, and median.
print_array() -  Given an array of data and a length, prints the array to the screen
find_median() - Given an array of data and a length, returns the median value
find_mean() -  Given an array of data and a length, returns the mean
find_maximum() -  Given an array of data and a length, returns the maximum
find_minimum() -  Given an array of data and a length, returns the minimum
sort_array() - Given an array of data and a length, sorts the array from largest to smallest.  (The zeroth Element should be the largest value, and the last element (n-1) should be the smallest value. )
